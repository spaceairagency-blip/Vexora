import express, { Express, Request, Response } from 'express';
import { GoogleGenAI, Type } from '@google/genai';
import fs from 'node:fs/promises';
import path from 'node:path';
import dns from 'node:dns/promises';
import net from 'node:net';

const PORT = Number(process.env.PORT) || 3000;
const SYNC_STORE_PATH = '/tmp/vexora-sync-vaults.json';
const UA =
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Vexora/2.0';

// --------------------------------------------------------------------------- //
//  Vexora Shield Tracker Domain Set (from original server.py + AI additions)
// --------------------------------------------------------------------------- //
const TRACKER_DOMAINS = new Set(
  `doubleclick.net googlesyndication.com googletagmanager.com google-analytics.com
googleadservices.com adservice.google.com pagead2.googlesyndication.com
connect.facebook.net facebook.net analytics.twitter.com ads-twitter.com static.ads-twitter.com
scorecardresearch.com quantserve.com quantcount.com hotjar.com static.hotjar.com
mixpanel.com cdn.segment.com segment.io amplitude.com criteo.com criteo.net
taboola.com outbrain.com adnxs.com rubiconproject.com pubmatic.com openx.net
adsrvr.org moatads.com chartbeat.com chartbeat.net bat.bing.com clarity.ms
fullstory.com mouseflow.com crazyegg.com mc.yandex.ru analytics.tiktok.com
tr.snapchat.com sc-static.net ads.pinterest.com px.ads.linkedin.com snap.licdn.com
amazon-adsystem.com adform.net smartadserver.com casalemedia.com 33across.com
bidswitch.net sharethrough.com teads.tv zedo.com media.net mgid.com revcontent.com
adroll.com addthis.com sharethis.com hs-analytics.net hsadspixel.net
bluekai.com demdex.net omtrdc.net everesttech.net krxd.net rlcdn.com
ads.yahoo.com advertising.com adtechus.com serving-sys.com yieldmo.com
2mdn.net ad.doubleclick.net track.adform.net optimizely.com cdn.heapanalytics.com
heap.io`
    .trim()
    .split(/\s+/)
);

const customBlockedPatterns = new Set<string>();

function isTrackerHost(hostname: string | null | undefined): boolean {
  if (!hostname) return false;
  const host = hostname.toLowerCase();
  const parts = host.split('.');
  for (let i = 0; i < parts.length - 1; i++) {
    const sub = parts.slice(i).join('.');
    if (TRACKER_DOMAINS.has(sub) || customBlockedPatterns.has(sub)) return true;
  }
  for (const pat of customBlockedPatterns) {
    if (pat && host.includes(pat.toLowerCase())) return true;
  }
  return false;
}

const AD_CSS =
  "ins.adsbygoogle,.adsbygoogle,[id^='google_ads'],[id^='div-gpt-ad'],iframe[src*='doubleclick.net'],iframe[src*='googlesyndication.com'],[data-ad-slot]{display:none!important}";
const BLANK_GIF =
  'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

// --------------------------------------------------------------------------- //
//  Zero-Knowledge Encrypted Sync Relay Store
// --------------------------------------------------------------------------- //
interface SyncVaultRecord {
  vaultId: string;
  salt: string;
  iv: string;
  ciphertext: string;
  algorithm: string;
  updatedAt: string;
  deviceLabel: string;
  byteLength: number;
}

const syncVaults = new Map<string, SyncVaultRecord>();
const faviconCache = new Map<string, { buf: Buffer; contentType: string }>();

async function loadSyncStore() {
  try {
    const raw = await fs.readFile(SYNC_STORE_PATH, 'utf8');
    const parsed = JSON.parse(raw) as Record<string, SyncVaultRecord>;
    for (const [k, v] of Object.entries(parsed)) {
      syncVaults.set(k, v);
    }
  } catch {
    // Store not created yet
  }
}

async function persistSyncStore() {
  try {
    await fs.writeFile(
      SYNC_STORE_PATH,
      JSON.stringify(Object.fromEntries(syncVaults.entries())),
      'utf8'
    );
  } catch {
    // Non-fatal
  }
}

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in server secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// --------------------------------------------------------------------------- //
//  SSRF Protection
// --------------------------------------------------------------------------- //
function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const parts = ip.split('.').map(Number);
    if (parts[0] === 10 || parts[0] === 127 || parts[0] === 0) return true;
    if (parts[0] === 169 && parts[1] === 254) return true;
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
    if (parts[0] === 192 && parts[1] === 168) return true;
    return false;
  }
  const n = ip.toLowerCase();
  return n === '::1' || n.startsWith('fc') || n.startsWith('fd') || n.startsWith('fe80');
}

async function assertSafePublicUrl(rawUrl: string): Promise<URL> {
  const parsed = new URL(rawUrl);
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error('Vexora can only open http:// and https:// addresses.');
  }
  const host = parsed.hostname.toLowerCase();
  if (host === 'localhost' || host.endsWith('.local') || host.endsWith('.internal')) {
    throw new Error("Vexora's proxy blocks local or internal network addresses.");
  }
  if (net.isIP(host) && isPrivateIp(host)) {
    throw new Error("Vexora's proxy blocks private-network IP ranges.");
  }
  try {
    const records = await dns.lookup(host, { all: true });
    for (const r of records) {
      if (isPrivateIp(r.address)) {
        throw new Error('Target resolves to a restricted private network.');
      }
    }
  } catch (err) {
    if (err instanceof Error && err.message.includes('restricted')) throw err;
  }
  return parsed;
}

// --------------------------------------------------------------------------- //
//  Vexora 2.0 Page Bridge (virtualizes storage, routing, & proxy fetches)
// --------------------------------------------------------------------------- //
const INJECT_JS = `/* Vexora 2.0 page bridge */
(function () {
  'use strict';
  var C = window.__VX;
  if (!C || window.__vxInit) return;
  window.__vxInit = 1;
  var P = (window.location && window.location.origin && window.location.origin !== 'null')
    ? window.location.origin
    : C.proxyOrigin;
  var _parentPost = null;
  try { _parentPost = window.parent && window.parent.postMessage ? window.parent.postMessage.bind(window.parent) : null; } catch (e) {}

  // Isolate proxied site storage in-memory so websites never crash or touch Vexora keys
  try {
    var makeMemStorage = function () {
      var map = Object.create(null);
      return {
        get length() { return Object.keys(map).length; },
        clear: function () { map = Object.create(null); },
        getItem: function (k) { k = String(k); return Object.prototype.hasOwnProperty.call(map, k) ? map[k] : null; },
        key: function (i) { return Object.keys(map)[i] || null; },
        removeItem: function (k) { delete map[String(k)]; },
        setItem: function (k, v) { map[String(k)] = String(v); }
      };
    };
    Object.defineProperty(window, 'localStorage', { value: makeMemStorage(), configurable: true });
    Object.defineProperty(window, 'sessionStorage', { value: makeMemStorage(), configurable: true });
  } catch (e) {}

  // Prevent proxied sites from colliding with Vexora's Service Worker on the shared origin
  try {
    var swStub = {
      register: function () {
        return Promise.resolve({
          scope: '/',
          active: null,
          installing: null,
          waiting: null,
          unregister: function () { return Promise.resolve(false); },
          update: function () { return Promise.resolve(); },
          addEventListener: function () {},
          removeEventListener: function () {}
        });
      },
      getRegistration: function () { return Promise.resolve(undefined); },
      getRegistrations: function () { return Promise.resolve([]); },
      addEventListener: function () {},
      removeEventListener: function () {},
      ready: new Promise(function () {}),
      controller: null
    };
    Object.defineProperty(navigator, 'serviceWorker', {
      configurable: true,
      get: function () { return swStub; }
    });
  } catch (e) {}

  function send(m) {
    m.vx = 1;
    try { if (_parentPost) _parentPost(m, '*'); } catch (e) {}
  }
  function abs(u) {
    try { return new URL(u, C.base).href; } catch (e) { return u; }
  }
  function isOurs(a) {
    return a.indexOf(P + '/proxy') === 0 || a.indexOf(P + '/__vx') === 0 || a.indexOf('/proxy?') === 0;
  }
  function prox(u) {
    var a = abs(String(u));
    if (/^https?:/i.test(a) && !isOurs(a)) {
      // Sites often build API URLs from location.origin, which is Vexora's origin inside the sandbox.
      // Point those back at the real site instead of letting the proxy fetch itself.
      if (a === P || a.indexOf(P + '/') === 0 || a.indexOf(P + '?') === 0) {
        try { a = new URL(C.page).origin + a.slice(P.length); } catch (e) {}
      }
      return P + '/proxy?url=' + encodeURIComponent(a) + '&s=' + (C.shield ? 1 : 0);
    }
    return u;
  }
  function go(url) {
    send({ t: 'nav', url: abs(url) });
  }

  try {
    if (window.fetch) {
      var of = window.fetch;
      window.fetch = function (i, init) {
        try {
          if (typeof i === 'string' || i instanceof URL) i = prox(i);
          else if (i && i.url) {
            var n = prox(i.url);
            if (n !== i.url) i = new Request(n, i);
          }
        } catch (e) {}
        return of.call(window, i, init);
      };
    }
    var ox = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function () {
      var a = Array.prototype.slice.call(arguments);
      a[1] = prox(a[1]);
      return ox.apply(this, a);
    };
    if (navigator.sendBeacon) {
      var ob = navigator.sendBeacon.bind(navigator);
      navigator.sendBeacon = function (u, d) { return ob(prox(u), d); };
    }
  } catch (e) {}

  window.open = function (u) {
    if (u) send({ t: 'open', url: abs(u) });
    return null;
  };

  // Patch the prototype as well as the instance: sites like YouTube call the native method
  // through History.prototype, which skipped the old instance-only override and threw a
  // SecurityError (the <base> makes their relative URL resolve to the real site's origin).
  ['pushState', 'replaceState'].forEach(function (k) {
    var o = History.prototype[k];
    var patched = function (s, t, u) {
      if (u == null) {
        try { return o.call(history, s, t); } catch (e) { return; }
      }
      // Sites rewrite location.pathname + search, which is our own /proxy?url=... URL. Ignore those.
      try {
        var cur = new URL(String(u), location.href);
        if (cur.origin === location.origin && cur.pathname === '/proxy') return;
      } catch (e) {}
      var a = abs(String(u));
      C.page = a;
      try { o.call(history, s, t); } catch (e) {}
      send({ t: 'push', url: a, title: document.title, replace: k === 'replaceState' });
    };
    try { History.prototype[k] = patched; } catch (e) {}
    try { Object.defineProperty(history, k, { value: patched, configurable: true, writable: true }); } catch (e) {}
  });

  document.addEventListener('click', function (e) {
    if (e.defaultPrevented) return;
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    var raw = a.getAttribute('href') || '';
    if (!raw || /^(javascript|mailto|tel|data|blob|sms):/i.test(raw)) return;
    if (raw.charAt(0) === '#') {
      e.preventDefault();
      var id = decodeURIComponent(raw.slice(1));
      var el = id ? (document.getElementById(id) || document.getElementsByName(id)[0]) : null;
      if (el) el.scrollIntoView(); else if (!id) scrollTo(0, 0);
      return;
    }
    var url = abs(raw);
    if (!/^https?:/i.test(url)) return;
    var newTab = e.ctrlKey || e.metaKey || e.button === 1 || (a.target && a.target !== '_self' && a.target !== '_top' && a.target !== '_parent');
    e.preventDefault();
    if (newTab) send({ t: 'open', url: url, bg: !!(e.ctrlKey || e.metaKey || e.button === 1) });
    else go(url);
  }, true);

  document.addEventListener('submit', function (e) {
    if (e.defaultPrevented || !e.target || e.target.tagName !== 'FORM') return;
    var f = e.target;
    var m = (f.getAttribute('method') || 'get').toLowerCase();
    var act = f.getAttribute('action') ? abs(f.getAttribute('action')) : C.page;
    if (m === 'get') {
      e.preventDefault();
      try {
        var u = new URL(act);
        var fd = new FormData(f);
        u.search = new URLSearchParams(fd).toString();
        go(u.href);
      } catch (x) { go(act); }
    } else {
      f.setAttribute('action', P + '/proxy?url=' + encodeURIComponent(act));
    }
  }, true);

  var lastTitle = null;
  function loaded() {
    lastTitle = document.title;
    send({ t: 'loaded', url: C.page, title: document.title || '', blocked: C.blocked || 0, blockedHosts: C.blockedHosts || [] });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', loaded);
  else loaded();

  setInterval(function () {
    if (document.title !== lastTitle) {
      lastTitle = document.title;
      send({ t: 'title', title: lastTitle });
    }
  }, 800);

  addEventListener('focus', function () { send({ t: 'focus' }); });
  addEventListener('mousedown', function () { send({ t: 'focus' }); }, true);

  addEventListener('keydown', function (e) {
    var k = e.key, m = e.ctrlKey || e.metaKey, a = e.altKey, c = e.code || '';
    var block = (m && !a && /^[kldfbhr=\\-+0,]$/i.test(k)) || (m && e.shiftKey && /^[sdpn]$/i.test(k)) || k === 'F5' || k === 'F6';
    if (block) e.preventDefault();
    if (block || k === 'Escape') send({ t: 'key', key: k, code: c, ctrl: m, alt: a, shift: e.shiftKey });
  }, true);

  var DARK = 'html{filter:invert(1) hue-rotate(180deg)!important;background:#fff!important}' +
             'img,video,picture,canvas,iframe,svg image,[style*="background-image"]{filter:invert(1) hue-rotate(180deg)!important}';

  addEventListener('message', function (e) {
    if (!e.data || e.data.vx !== 1) return;
    var d = e.data;
    if (d.c === 'zoom') document.documentElement.style.zoom = d.v === 1 ? '' : d.v;
    else if (d.c === 'dark') {
      var s = document.getElementById('vx-dark');
      if (d.on && !s) {
        s = document.createElement('style');
        s.id = 'vx-dark';
        s.textContent = DARK;
        (document.head || document.documentElement).appendChild(s);
      } else if (!d.on && s) s.remove();
    } else if (d.c === 'find') {
      var q = d.q || '', sel = window.getSelection();
      if (!q) { sel.removeAllRanges(); send({ t: 'find', count: 0 }); return; }
      var count = 0;
      try {
        var re = new RegExp(q.replace(/[.*+?^\${}()|[\\]\\\\]/g, '\\\\$&'), 'gi');
        var mat = (document.body.innerText || '').match(re);
        count = mat ? mat.length : 0;
      } catch (x) {}
      var ok = false;
      try { ok = window.find(q, false, !!d.back, true, false, false, false); } catch (x) {}
      send({ t: 'find', count: count, ok: ok });
    } else if (d.c === 'print') window.print();
    else if (d.c === 'top') window.scrollTo({ top: 0, behavior: 'smooth' });
    else if (d.c === 'stop') window.stop();
  });
})();`;

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function renderProxyErrorPage(status: number, title: string, message: string, targetUrl = ''): string {
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escapeHtml(title)}</title><style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#080b14;color:#e8eeff;font:15px/1.55 system-ui,-apple-system,sans-serif}
.card{max-width:520px;margin:24px;padding:34px;border:1px solid #8aa6ff22;border-radius:20px;background:#0e1424ee;box-shadow:0 20px 60px #0008}
.code{display:inline-block;font:600 12px ui-monospace,monospace;color:#19e3ff;background:#19e3ff14;border:1px solid #19e3ff33;padding:3px 10px;border-radius:99px}
h1{margin:16px 0 8px;font-size:24px}
p{margin:0 0 8px;color:#9aa7cc}code{color:#cfd9ff;word-break:break-all;font-size:12px}
button{margin-top:16px;border:0;border-radius:10px;padding:10px 18px;font:600 13px inherit;color:#fff;cursor:pointer;background:linear-gradient(90deg,#2a5bff,#8a3dff)}
</style></head><body><div class="card"><span class="code">ERROR ${status}</span><h1>${escapeHtml(title)}</h1><p>${escapeHtml(message)}</p><p><code>${escapeHtml(targetUrl)}</code></p>
<button onclick="location.reload()">Try again</button></div>
<script>try{parent.postMessage({vx:1,t:"loaded",url:${JSON.stringify(targetUrl)},title:${JSON.stringify(title)},blocked:0,error:true},"*")}catch(e){}</script>
</body></html>`;
}

// --------------------------------------------------------------------------- //
//  Sites that cannot be proxied (YouTube, Facebook, ...) get a purpose-built page
// --------------------------------------------------------------------------- //
const UNPROXYABLE_SOCIAL: Array<{ domain: string; name: string }> = [
  { domain: 'facebook.com', name: 'Facebook' },
  { domain: 'fb.com', name: 'Facebook' },
  { domain: 'fb.watch', name: 'Facebook' },
  { domain: 'fb.me', name: 'Facebook' },
  { domain: 'messenger.com', name: 'Messenger' },
  { domain: 'instagram.com', name: 'Instagram' },
];

function hostMatches(host: string, domain: string): boolean {
  return host === domain || host.endsWith('.' + domain);
}

function parseYouTubeStart(raw: string | null): number {
  if (!raw) return 0;
  if (/^\d+$/.test(raw)) return Number(raw);
  const m = raw.match(/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$/i);
  if (!m) return 0;
  return Number(m[1] || 0) * 3600 + Number(m[2] || 0) * 60 + Number(m[3] || 0);
}

function renderSitePage(opts: {
  title: string;
  heading: string;
  message: string;
  originalUrl: string;
  openLabel: string;
  embedSrc?: string;
  pasteBox?: boolean;
}): string {
  const jsUrl = JSON.stringify(opts.originalUrl).replace(/</g, '\\u003c');
  const jsTitle = JSON.stringify(opts.title).replace(/</g, '\\u003c');
  const player = opts.embedSrc
    ? `<div class="player"><iframe src="${escapeHtml(opts.embedSrc)}" title="${escapeHtml(opts.title)}"
allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></div>`
    : '';
  const paste = opts.pasteBox
    ? `<form id="go"><input id="link" type="text" placeholder="Paste a YouTube video link to watch it here" autocomplete="off"><button type="submit">Watch</button></form>`
    : '';
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escapeHtml(opts.title)}</title><style>
*{box-sizing:border-box}html,body{margin:0;min-height:100%}
body{display:flex;flex-direction:column;align-items:center;gap:16px;padding:24px;background:#080b14;color:#e8eeff;font:15px/1.55 system-ui,-apple-system,sans-serif}
.player{width:min(1100px,100%,calc((100vh - 150px)*16/9));aspect-ratio:16/9;border-radius:16px;overflow:hidden;background:#000;box-shadow:0 20px 60px #0008}
.player iframe{width:100%;height:100%;border:0}
.card{width:min(560px,100%);padding:26px;border:1px solid #8aa6ff22;border-radius:20px;background:#0e1424ee;text-align:center}
.card.wide{width:min(1100px,100%);display:flex;align-items:center;justify-content:space-between;gap:16px;text-align:left;padding:14px 20px}
h1{margin:0 0 8px;font-size:21px}p{margin:0;color:#9aa7cc}
button{border:0;border-radius:10px;padding:10px 18px;font:600 13px inherit;color:#fff;cursor:pointer;background:linear-gradient(90deg,#2a5bff,#8a3dff);white-space:nowrap}
form{display:flex;gap:8px;margin-top:18px}input{flex:1;min-width:0;border:1px solid #8aa6ff33;border-radius:10px;padding:10px 12px;background:#080b14;color:#e8eeff;font:inherit}
</style></head><body>
${player}
<div class="card${opts.embedSrc ? ' wide' : ''}"><div><h1>${escapeHtml(opts.heading)}</h1><p>${escapeHtml(opts.message)}</p></div>
${opts.embedSrc ? '' : '<div style="margin-top:18px">'}<button id="ext" type="button">${escapeHtml(opts.openLabel)}</button>${opts.embedSrc ? '' : '</div>'}
${paste}</div>
<script>
var U=${jsUrl},T=${jsTitle};
function post(m){m.vx=1;try{parent.postMessage(m,"*")}catch(e){}}
post({t:"loaded",url:U,title:T,blocked:0});
document.getElementById("ext").onclick=function(){post({t:"external",url:U})};
var f=document.getElementById("go");
if(f)f.onsubmit=function(e){e.preventDefault();var v=document.getElementById("link").value.trim();
if(!v)return;if(!/^https?:/i.test(v))v="https://"+v;post({t:"nav",url:v})};
</script></body></html>`;
}

function getKnownSitePage(target: URL): string | null {
  const host = target.hostname.toLowerCase().replace(/^www\./, '');
  const original = target.toString();

  if (hostMatches(host, 'youtube.com') || host === 'youtu.be') {
    let id = '';
    if (host === 'youtu.be') {
      id = target.pathname.slice(1).split('/')[0];
    } else {
      const m = target.pathname.match(/^\/(?:shorts|embed|live|v)\/([\w-]{11})/);
      if (m) id = m[1];
      else if (target.pathname === '/watch') id = target.searchParams.get('v') || '';
    }
    if (/^[\w-]{11}$/.test(id)) {
      const start = parseYouTubeStart(target.searchParams.get('t') || target.searchParams.get('start'));
      const list = target.searchParams.get('list') || '';
      let src = `https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0&playsinline=1`;
      if (start > 0) src += `&start=${start}`;
      if (/^[\w-]+$/.test(list)) src += `&list=${list}`;
      return renderSitePage({
        title: 'YouTube video',
        heading: 'Playing in the Vexora YouTube player',
        message: 'Comments, recommendations and sign-in are on YouTube itself.',
        originalUrl: original,
        openLabel: 'Open on YouTube',
        embedSrc: src,
      });
    }
    return renderSitePage({
      title: 'YouTube',
      heading: 'YouTube can’t load its full site inside a proxy',
      message:
        'YouTube’s home, search and channel pages need your login and live tokens. Paste a video link to watch it right here, or open YouTube in a normal tab.',
      originalUrl: original,
      openLabel: 'Open YouTube',
      pasteBox: true,
    });
  }

  for (const site of UNPROXYABLE_SOCIAL) {
    if (hostMatches(host, site.domain)) {
      return renderSitePage({
        title: site.name,
        heading: `${site.name} can’t be opened inside Vexora`,
        message: `${site.name} requires you to be logged in and rejects requests that come through a proxy server, so it can’t load here. Open it in a normal tab instead.`,
        originalUrl: original,
        openLabel: `Open ${site.name}`,
      });
    }
  }
  return null;
}

function processProxyHtml(
  rawHtml: string,
  finalUrl: string,
  proxyOrigin: string,
  shield: boolean
): { html: string; blocked: number; blockedHosts: string[] } {
  let base = finalUrl;
  const baseMatch = rawHtml.match(/<base\b[^>]*href\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i);
  if (baseMatch) {
    try {
      base = new URL(baseMatch[1] || baseMatch[2] || baseMatch[3] || '', finalUrl).toString();
    } catch {
      base = finalUrl;
    }
  }

  let text = rawHtml
    .replace(/<base\b[^>]*>/gi, '')
    .replace(/<link\b[^>]*\brel\s*=\s*["']?manifest["']?[^>]*>/gi, '')
    .replace(/<meta\b[^>]*http-equiv\s*=\s*["']?(?:content-security-policy|x-frame-options)[^>]*>/gi, '')
    .replace(
      /<meta\b([^>]*)http-equiv\s*=\s*["']?refresh["']?([^>]*)>/gi,
      (_full, pre, post) => {
        const attrs = `${pre} ${post}`;
        const m = attrs.match(/content\s*=\s*["']([^"']+)["']/i);
        if (!m) return '';
        const delayNum = Number.parseFloat(m[1].split(';')[0].trim() || '0');
        const urlPart = m[1].match(/url\s*=\s*['"]?([^'";\s]+)/i);
        if (!urlPart) {
          return Number.isFinite(delayNum) && delayNum <= 5 ? '' : _full;
        }
        try {
          const target = new URL(urlPart[1], base).toString();
          if (target === finalUrl && Number.isFinite(delayNum) && delayNum <= 5) {
            return '';
          }
          const proxied = `${proxyOrigin}/proxy?url=${encodeURIComponent(target)}&s=${shield ? 1 : 0}`;
          const delay = m[1].split(';')[0].trim() || '0';
          return `<meta http-equiv="refresh" content="${escapeHtml(delay)};url=${escapeHtml(proxied)}">`;
        } catch {
          return '';
        }
      }
    )
    .replace(/(<a\b[^>]*\btarget\s*=\s*["']?)(?:_top|_parent)/gi, '$1_self');

  let blocked = 0;
  const blockedHosts = new Set<string>();

  if (shield) {
    text = text.replace(/<(script|iframe|img)\b([^>]*)>/gi, (full, rawTag, attrs) => {
      const tag = String(rawTag).toLowerCase();
      const srcMatch = String(attrs).match(
        /(?:^|\s)(?:src|data-src)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i
      );
      if (!srcMatch) return full;
      const src = srcMatch[1] || srcMatch[2] || srcMatch[3] || '';
      try {
        const host = new URL(src, base).hostname;
        if (!isTrackerHost(host)) return full;
        blocked += 1;
        blockedHosts.add(host);
        if (tag === 'script') return '<script type="vexora/blocked">';
        if (tag === 'iframe') return '<iframe src="about:blank" hidden>';
        return `<img src="${BLANK_GIF}" width="1" height="1" alt="">`;
      } catch {
        return full;
      }
    });

    text = text.replace(/<script\b(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi, (full, body) => {
      if (/\b(?:gtag|fbq|_gaq|adsbygoogle|__tcfapi)\s*\(/i.test(String(body))) {
        blocked += 1;
        blockedHosts.add('inline-tracker');
        return '<script type="vexora/blocked"></script>';
      }
      return full;
    });
  }

  const cfg = JSON.stringify({
    base,
    page: finalUrl,
    proxyOrigin,
    shield,
    blocked,
    blockedHosts: Array.from(blockedHosts),
  }).replace(/</g, '\\u003c');

  const safeInlineBridge = INJECT_JS.replace(/<\/script>/gi, '<\\/script>');
  const injectBlock =
    `<script>window.__VX=${cfg};</script>` +
    `<script>${safeInlineBridge}</script>` +
    `<base href="${escapeHtml(base)}">` +
    (shield ? `<style>${AD_CSS}</style>` : '');

  if (/<head\b[^>]*>/i.test(text)) {
    text = text.replace(/<head\b[^>]*>/i, (m) => m + injectBlock);
  } else if (/<html\b[^>]*>/i.test(text)) {
    text = text.replace(/<html\b[^>]*>/i, (m) => `${m}<head>${injectBlock}</head>`);
  } else {
    text = `<head>${injectBlock}</head>${text}`;
  }

  return { html: text, blocked, blockedHosts: Array.from(blockedHosts) };
}

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)));
}

function stripTags(s: string): string {
  return decodeEntities(s.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
}

function buildReaderPayload(html: string, url: string) {
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const ogTitle = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i);
  const authorMatch = html.match(/<meta[^>]+name=["']author["'][^>]+content=["']([^"']+)["']/i);
  const siteMatch = html.match(/<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i);

  const cleaned = html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<nav[\s\S]*?<\/nav>/gi, ' ')
    .replace(/<footer[\s\S]*?<\/footer>/gi, ' ')
    .replace(/<aside[\s\S]*?<\/aside>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ');

  const blocks: string[] = [];
  const plainParts: string[] = [];
  const blockRe = /<(h1|h2|h3|p|blockquote|pre|li)[^>]*>([\s\S]*?)<\/\1>/gi;
  let m: RegExpExecArray | null;
  while ((m = blockRe.exec(cleaned)) !== null && blocks.length < 120) {
    const tag = m[1].toLowerCase();
    const txt = stripTags(m[2]);
    if (!txt) continue;
    if (tag === 'p' && txt.length < 40) continue;
    plainParts.push(txt);
    blocks.push(`<${tag}>${escapeHtml(txt)}</${tag}>`);
  }

  const words = plainParts.join(' ').split(/\s+/).filter(Boolean).length;
  const host = new URL(url).hostname;
  return {
    title: decodeEntities((ogTitle?.[1] || (titleMatch ? stripTags(titleMatch[1]) : '') || host).trim()),
    byline: authorMatch ? decodeEntities(authorMatch[1].trim()) : '',
    site: siteMatch ? decodeEntities(siteMatch[1].trim()) : host,
    html: blocks.join(''),
    textPreview: plainParts.slice(0, 4).join(' ').slice(0, 320),
    words,
    minutes: Math.max(1, Math.round(words / 220)),
    url,
  };
}

// Normalises the request body for /proxy, whether it came from express.raw (Buffer)
// or was already parsed by the host runtime (string / object, e.g. on Vercel).
function getProxyRequestBody(req: Request): Buffer | undefined {
  const body: unknown = req.body;
  if (body === undefined || body === null) return undefined;
  if (Buffer.isBuffer(body)) return body;
  if (typeof body === 'string') return Buffer.from(body);
  if (typeof body === 'object') {
    if (Object.keys(body as object).length === 0) return undefined;
    const ct = String(req.headers['content-type'] || '');
    if (ct.includes('application/x-www-form-urlencoded')) {
      return Buffer.from(new URLSearchParams(body as Record<string, string>).toString());
    }
    return Buffer.from(JSON.stringify(body));
  }
  return undefined;
}

let appPromise: Promise<Express> | null = null;

export async function getVexoraApp(): Promise<Express> {
  if (appPromise) return appPromise;

  appPromise = (async () => {
    await loadSyncStore();
    const app = express();

    app.use((req, _res, next) => {
      if (req.body !== undefined) {
        (req as Request & { _body?: boolean })._body = true;
      }
      next();
    });
    app.use('/proxy', express.raw({ type: () => true, limit: '4mb' }));
    app.use(express.json({ limit: '4mb' }));

    app.get('/api/health', (_req: Request, res: Response) => {
      res.json({ ok: true, app: 'Vexora', version: '2.0.0', build: 'fixes-2026-11-14' });
    });

    // Serve Vexora page bridge script
    app.get('/__vx/inject.js', (_req: Request, res: Response) => {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cache-Control', 'public, max-age=300');
      res.send(INJECT_JS);
    });

    // First-Party Vexora Private Search Endpoint (zero cookies/user IP forwarded)
    app.get('/api/search', async (req: Request, res: Response) => {
      const q = String(req.query.q || '').trim();
      if (!q) {
        res.status(400).json({ error: 'Missing query parameter q' });
        return;
      }

      const started = Date.now();
      const results: Array<{
        id: string;
        title: string;
        url: string;
        snippet: string;
        domain: string;
        category: string;
      }> = [];
      const seenUrls = new Set<string>();

      const addResult = (item: {
        title: string;
        url: string;
        snippet: string;
        category: string;
      }) => {
        try {
          const parsed = new URL(item.url);
          if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return;
          const cleanUrl = parsed.toString();
          if (seenUrls.has(cleanUrl)) return;
          seenUrls.add(cleanUrl);
          results.push({
            id: `web-${seenUrls.size}-${Date.now()}`,
            title: item.title.trim() || parsed.hostname,
            url: cleanUrl,
            snippet: item.snippet.trim() || cleanUrl,
            domain: parsed.hostname.replace(/^www\./, ''),
            category: item.category,
          });
        } catch {
          // ignore invalid URL
        }
      };

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 7000);

      try {
        const [ddgRes, wikiRes, hnRes] = await Promise.allSettled([
          fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`, {
            signal: controller.signal,
            headers: { 'User-Agent': UA, Accept: 'text/html' },
          }).then((r) => (r.ok ? r.text() : '')),
          fetch(
            `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&utf8=&format=json&srlimit=5`,
            {
              signal: controller.signal,
              headers: { 'User-Agent': 'VexoraSearchBot/2.0' },
            }
          ).then((r) => (r.ok ? r.json() : null)),
          fetch(
            `https://hn.algolia.com/api/v1/search?query=${encodeURIComponent(q)}&hitsPerPage=4`,
            { signal: controller.signal }
          ).then((r) => (r.ok ? r.json() : null)),
        ]);

        if (ddgRes.status === 'fulfilled' && ddgRes.value) {
          const html = ddgRes.value;
          const blockRe =
            /<a[^>]+class="[^"]*result__a[^"]*"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:<a[^>]+class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/a>|<div[^>]+class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/div>)?/gi;
          let m: RegExpExecArray | null;
          while ((m = blockRe.exec(html)) !== null && results.length < 10) {
            let rawHref = decodeEntities(m[1]);
            if (rawHref.includes('uddg=')) {
              try {
                const u = new URL(rawHref, 'https://duckduckgo.com');
                const uddg = u.searchParams.get('uddg');
                if (uddg) rawHref = uddg;
              } catch {
                // ignore
              }
            } else if (rawHref.startsWith('//')) {
              rawHref = `https:${rawHref}`;
            }
            if (rawHref.includes('duckduckgo.com/y.js') || rawHref.includes('ad_provider=')) {
              continue;
            }
            addResult({
              title: stripTags(m[2]),
              url: rawHref,
              snippet: stripTags(m[3] || m[4] || ''),
              category: 'Web Index',
            });
          }
        }

        if (wikiRes.status === 'fulfilled' && wikiRes.value?.query?.search) {
          const hits = wikiRes.value.query.search as Array<{
            title: string;
            snippet: string;
          }>;
          for (const h of hits.slice(0, 4)) {
            addResult({
              title: `${h.title} — Wikipedia`,
              url: `https://en.wikipedia.org/wiki/${encodeURIComponent(h.title.replace(/ /g, '_'))}`,
              snippet: stripTags(h.snippet),
              category: 'Encyclopedia',
            });
          }
        }

        if (hnRes.status === 'fulfilled' && hnRes.value?.hits) {
          const hits = hnRes.value.hits as Array<{
            title?: string;
            url?: string;
            objectID?: string;
            points?: number;
          }>;
          for (const h of hits.slice(0, 3)) {
            const targetUrl =
              h.url || `https://news.ycombinator.com/item?id=${encodeURIComponent(h.objectID || '')}`;
            if (h.title) {
              addResult({
                title: h.title,
                url: targetUrl,
                snippet: `Community discussion (${h.points || 0} points) indexed via Vexora Crawler.`,
                category: 'Tech & Discussions',
              });
            }
          }
        }
      } finally {
        clearTimeout(timeout);
      }

      res.json({
        query: q,
        results,
        elapsedMs: Date.now() - started,
        privacy: 'Zero client IP/cookies forwarded · Server-stripped',
      });
    });

    // Vexora Sandbox Proxy (/proxy?url=...&s=1&f=1)
    app.all('/proxy', async (req: Request, res: Response) => {
      const rawUrl = String(req.query.url || '');
      const shield = req.query.s !== '0';
      const fallback = req.query.f === '1';

      if (!rawUrl) {
        res.status(400).send(renderProxyErrorPage(400, 'No address', 'Nothing to load.'));
        return;
      }

      const fwdProto = req.headers['x-forwarded-proto'];
      const proto =
        (Array.isArray(fwdProto) ? fwdProto[0] : fwdProto)?.split(',')[0]?.trim() ||
        req.protocol ||
        'https';
      const fwdHost = req.headers['x-forwarded-host'];
      const host =
        (Array.isArray(fwdHost) ? fwdHost[0] : fwdHost)?.split(',')[0]?.trim() ||
        req.headers.host ||
        `localhost:${PORT}`;
      const proxyOrigin = `${proto}://${host}`;

      try {
        const safeUrl = await assertSafePublicUrl(rawUrl);

        // Page loads of YouTube/Facebook/Instagram get a purpose-built page instead of a broken proxy.
        const navDest = String(req.headers['sec-fetch-dest'] || '');
        const isNavRequest = !navDest || ['document', 'iframe', 'frame'].includes(navDest);
        if (req.method === 'GET' && isNavRequest) {
          const special = getKnownSitePage(safeUrl);
          if (special) {
            res.status(200);
            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            res.setHeader('Cache-Control', 'no-store');
            res.send(special);
            return;
          }
        }

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 14000);

        const method = req.method.toUpperCase();
        const hasBody = method !== 'GET' && method !== 'HEAD';
        const bodyBytes = hasBody ? getProxyRequestBody(req) : undefined;
        const buildInit = (target: URL): RequestInit => {
          const headers: Record<string, string> = {
            'User-Agent': UA,
            Accept: String(req.headers.accept || 'text/html,application/xhtml+xml,*/*;q=0.8'),
            Origin: target.origin,
            Referer: target.origin + '/',
          };
          const lang = req.headers['accept-language'];
          if (lang) headers['Accept-Language'] = String(lang);
          if (hasBody && req.headers['content-type']) {
            headers['Content-Type'] = String(req.headers['content-type']);
          }
          for (const [k, v] of Object.entries(req.headers)) {
            if (v && /^(x-youtube-|x-goog-|x-requested-with$)/i.test(k)) {
              headers[k] = Array.isArray(v) ? v.join(', ') : String(v);
            }
          }
          return {
            method,
            redirect: 'follow',
            signal: controller.signal,
            headers,
            ...(bodyBytes && bodyBytes.length ? { body: new Uint8Array(bodyBytes) } : {}),
          };
        };

        let upstream: globalThis.Response;
        try {
          upstream = await fetch(safeUrl.toString(), buildInit(safeUrl));
        } catch (err) {
          if (fallback && safeUrl.protocol === 'https:') {
            const httpFallback = 'http://' + safeUrl.toString().slice('https://'.length);
            const fbUrl = await assertSafePublicUrl(httpFallback);
            upstream = await fetch(httpFallback, buildInit(fbUrl));
          } else {
            throw err;
          }
        } finally {
          clearTimeout(timeout);
        }

        const finalUrl = upstream.url || safeUrl.toString();
        await assertSafePublicUrl(finalUrl);

        const ctype = upstream.headers.get('content-type') || 'application/octet-stream';
        const status = upstream.status === 304 ? 200 : upstream.status;

        // Only page navigations get the bridge injected; fetch/XHR responses pass through untouched.
        const fetchDest = String(req.headers['sec-fetch-dest'] || '');
        const isPageNavigation = !fetchDest || ['document', 'iframe', 'frame'].includes(fetchDest);
        if (isPageNavigation && (ctype.includes('text/html') || ctype.includes('application/xhtml'))) {
          const text = await upstream.text();
          const isChallenge =
            (status === 403 || status === 429 || status === 503) &&
            (upstream.headers.get('cf-mitigated') === 'challenge' ||
              /just a moment|enable javascript and cookies|cf-browser-verification/i.test(text) ||
              !text.trim());

          if (isChallenge) {
            res
              .status(status)
              .setHeader('Content-Type', 'text/html; charset=utf-8')
              .send(
                renderProxyErrorPage(
                  status,
                  'Site Bot Protection Triggered',
                  `${new URL(finalUrl).hostname} blocked the cloud proxy request (HTTP ${status}). Try Reader Mode or click "Original" above to open directly.`,
                  finalUrl
                )
              );
            return;
          }

          const processed = processProxyHtml(text, finalUrl, proxyOrigin, shield);
          res.status(status);
          res.setHeader('Content-Type', 'text/html; charset=utf-8');
          res.setHeader('Access-Control-Allow-Origin', '*');
          res.setHeader('Cache-Control', 'no-store');
          res.send(processed.html);
          return;
        }

        const arrayBuf = await upstream.arrayBuffer();
        res.status(status);
        res.setHeader('Content-Type', ctype);
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Cache-Control', hasBody ? 'no-store' : 'private, max-age=300');
        res.send(Buffer.from(arrayBuf));
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Could not reach upstream site.';
        res
          .status(502)
          .setHeader('Content-Type', 'text/html; charset=utf-8')
          .send(renderProxyErrorPage(502, "Couldn't connect", msg, rawUrl));
      }
    });

    // Vexora Reader Mode extractor
    app.get('/api/reader', async (req: Request, res: Response) => {
      try {
        const rawUrl = String(req.query.url || '');
        const safeUrl = await assertSafePublicUrl(rawUrl);
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 10000);
        let upstream: globalThis.Response;
        try {
          upstream = await fetch(safeUrl.toString(), {
            signal: controller.signal,
            headers: { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml' },
          });
        } finally {
          clearTimeout(timeout);
        }
        const ctype = upstream.headers.get('content-type') || '';
        if (!ctype.includes('html')) {
          res.status(415).json({ error: 'Reader mode only works on HTML articles.' });
          return;
        }
        const html = await upstream.text();
        res.json(buildReaderPayload(html, upstream.url || safeUrl.toString()));
      } catch (err) {
        res.status(502).json({
          error: err instanceof Error ? err.message : 'Unable to extract article.',
        });
      }
    });

    // Favicon proxy
    app.get('/api/favicon', async (req: Request, res: Response) => {
      const domain = String(req.query.d || '').toLowerCase();
      if (!/^[a-z0-9]([a-z0-9\-.]{0,251}[a-z0-9])?$/i.test(domain)) {
        res.status(400).send('bad domain');
        return;
      }
      const cached = faviconCache.get(domain);
      if (cached) {
        if (!cached.buf.length) {
          res.status(204).end();
          return;
        }
        res.setHeader('Content-Type', cached.contentType);
        res.setHeader('Cache-Control', 'public, max-age=86400');
        res.send(cached.buf);
        return;
      }
      try {
        const r = await fetch(`https://icons.duckduckgo.com/ip3/${encodeURIComponent(domain)}.ico`, {
          headers: { 'User-Agent': UA },
        });
        if (!r.ok) throw new Error('no icon');
        const buf = Buffer.from(await r.arrayBuffer());
        const contentType = r.headers.get('content-type') || 'image/x-icon';
        if (faviconCache.size > 400) faviconCache.clear();
        faviconCache.set(domain, { buf, contentType });
        res.setHeader('Content-Type', contentType);
        res.setHeader('Cache-Control', 'public, max-age=86400');
        res.send(buf);
      } catch {
        faviconCache.set(domain, { buf: Buffer.alloc(0), contentType: '' });
        res.status(204).end();
      }
    });

    // Gemini AI-Powered Ad, Tracker & Dark-Pattern Analyzer
    app.post('/api/shield/analyze', async (req: Request, res: Response) => {
      try {
        const { url, contentSnippet, scriptUrls = [] } = req.body as {
          url?: string;
          contentSnippet?: string;
          scriptUrls?: string[];
        };
        if (!url && !contentSnippet) {
          res.status(400).json({ error: 'Provide a URL or DOM snippet to inspect.' });
          return;
        }

        const ai = getAiClient();
        const prompt = [
          'Inspect this target URL, DOM/HTML snippet, and script references for ad networks, CNAME-cloaked trackers, dark patterns, or phishing indicators.',
          `Target URL: ${url || 'inline-snippet'}`,
          `Scripts: ${scriptUrls.slice(0, 20).join(', ') || 'none'}`,
          `Snippet:\n${(contentSnippet || '').slice(0, 4000)}`,
        ].join('\n\n');

        const result = await ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: prompt,
          config: {
            systemInstruction:
              'You are Vexora AI Shield, a browser security and ad-blocking classifier. Return concise findings, riskScore (0-100), and deterministic CSS selectors or domain patterns.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                verdict: {
                  type: Type.STRING,
                  description: 'clean, ad_network, tracker, dark_pattern, or phishing_risk',
                },
                riskScore: { type: Type.INTEGER },
                blockedSelectors: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                blockedDomains: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                findings: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      category: { type: Type.STRING },
                      reason: { type: Type.STRING },
                      severity: { type: Type.STRING },
                    },
                  },
                },
                summary: { type: Type.STRING },
              },
            },
          },
        });

        const parsed = JSON.parse((result.text ?? '{}').trim()) as {
          blockedDomains?: string[];
        };
        for (const dom of parsed.blockedDomains || []) {
          if (dom && dom.includes('.')) {
            customBlockedPatterns.add(dom.trim().toLowerCase());
          }
        }
        res.json(parsed);
      } catch (err) {
        res.status(500).json({
          error: err instanceof Error ? err.message : 'AI Shield analysis failed.',
        });
      }
    });

    // Zero-Knowledge Cross-Device Encrypted Sync Relay
    app.post('/api/sync/:vaultId', async (req: Request, res: Response) => {
      try {
        const vaultId = String(req.params.vaultId || '').trim();
        if (!/^[a-zA-Z0-9_-]{6,64}$/.test(vaultId)) {
          res.status(400).json({ error: 'Invalid Sync Vault ID.' });
          return;
        }
        const { salt, iv, ciphertext, algorithm, deviceLabel } = req.body as {
          salt?: string;
          iv?: string;
          ciphertext?: string;
          algorithm?: string;
          deviceLabel?: string;
        };
        if (!salt || !iv || !ciphertext) {
          res.status(400).json({ error: 'Encrypted payload must include salt, iv, and ciphertext.' });
          return;
        }
        const record: SyncVaultRecord = {
          vaultId,
          salt,
          iv,
          ciphertext,
          algorithm: algorithm || 'AES-256-GCM',
          updatedAt: new Date().toISOString(),
          deviceLabel: (deviceLabel || 'Vexora Desktop').slice(0, 48),
          byteLength: ciphertext.length,
        };
        syncVaults.set(vaultId, record);
        await persistSyncStore();
        res.json({
          ok: true,
          vaultId: record.vaultId,
          updatedAt: record.updatedAt,
          byteLength: record.byteLength,
        });
      } catch (err) {
        res.status(500).json({ error: err instanceof Error ? err.message : 'Sync push failed.' });
      }
    });

    app.get('/api/sync/:vaultId', (req: Request, res: Response) => {
      const vaultId = String(req.params.vaultId || '').trim();
      const record = syncVaults.get(vaultId);
      if (!record) {
        res.status(404).json({ error: 'No encrypted sync snapshot found for this Vault ID.' });
        return;
      }
      res.json(record);
    });

    // Graceful fallback if someone accesses /api/index directly on Vercel
    app.get('/api/index', (_req: Request, res: Response) => {
      res.json({ ok: true, app: 'Vexora', version: '2.0.0', build: 'fixes-2026-11-14' });
    });

    return app;
  })();

  return appPromise;
}
