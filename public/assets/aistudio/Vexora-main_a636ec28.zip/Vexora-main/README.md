# Vexora Browser

A privacy-first browser shell featuring a sandboxed web proxy, first-party encrypted local search (`AES-256-GCM`), Gemini AI ad/dark-pattern shield, tab hibernation & workspaces, focus/productivity dashboard, zero-knowledge cross-device sync, and installable PWA support.

## Requirements

- **Node.js 20+** (recommended v20 or v22)
- **npm** (comes with Node.js)
- **Gemini API Key** (optional, required only for the AI Shield DOM analyzer at `vexora://shield`)

## Quick Start (From GitHub)

1. **Clone your repository**
   ```bash
   git clone <YOUR_GITHUB_REPO_URL>
   cd <YOUR_REPO_FOLDER>
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables**
   Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
   Edit `.env` and add your Gemini API key (if using AI Shield analysis):
   ```env
   GEMINI_API_KEY="your_gemini_api_key_here"
   PORT=3000
   ```

4. **Run in Development Mode**
   ```bash
   npm run dev
   ```
   Open **http://localhost:3000** in your browser.

## Production Build & Start

```bash
npm run build
NODE_ENV=production npm start
```
The server listens on `http://0.0.0.0:3000` (or `process.env.PORT`).

## Deploy to the Web (No-Code Hosting)

Deploy directly from GitHub:
- **Vercel**: Auto-configured via `vercel.json` and `api/index.ts` (serves static PWA + serverless `/proxy` and `/api/*` endpoints). Add optional `GEMINI_API_KEY` in Vercel Project Environment Variables.
- **Render / Railway / Fly.io / Google Cloud Run**:
  - **Build command**: `npm install && npm run build`
  - **Start command**: `NODE_ENV=production npm start`
  - **Environment variable**: `GEMINI_API_KEY`
